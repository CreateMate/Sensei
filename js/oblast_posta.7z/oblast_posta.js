//$(document).ready(function(){
//    $('.middle-funterest').hover(function(){
//        
//        $(this).css("opacity","0.8");
//       
//        $(this).find('.senseiLike-wrapper').css("display","block").fadeIn("slow");
//    },
//    function(){
//        $(this).css("opacity","1");
//        $(this).find('.senseiLike-wrapper').css("display","none");
//    });
//});

function ajaxLike(id)
{
   var xhttp;
  
    if (window.XMLHttpRequest) 
    {
     
      xhttp = new XMLHttpRequest();
      } 
      else 
      {
    
      xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
        xhttp.open("POST", "Sadrzaj/dodajLike/"+id, true);
        xhttp.send();
        xhttp.onreadystatechange = function() 
        {
            if (xhttp.readyState == 4 && xhttp.status == 200) 
            {
               $(".middle-lightup-inner ispis").find("#"+id).css("display","hidden");
            }
        }
}
function ajaxOnKeyUp()
{
    var naslov=$("#UserName").val();
    
    
    var xhttp;
  
    if (window.XMLHttpRequest) 
    {
     
      xhttp = new XMLHttpRequest();
      } 
      else 
      {
    
      xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    
        xhttp.open("GET", "http://localhost/Sajt/Sadrzaj/like/"+naslov, true);
    
        xhttp.send();
        xhttp.onreadystatechange = function() 
        {
            if(xhttp.readyState==1)
            {
                console.log(1);
            }
            if(xhttp.readyState==2)
            {
                console.log(2);
            }
            if(xhttp.readyState==3)
            {
                console.log(3);
            }
            if (xhttp.readyState == 4 && xhttp.status == 200) 
            {
              document.getElementById("sadrzaj").innerHTML=xhttp.responseText;
            }
        }
}